package com.mrsquaretech.service;

import org.springframework.stereotype.Service;

import com.mrsquaretech.entity.Employee;

@Service
public interface EmpSerice {

	public Employee saveEmp(Employee employee);
}
