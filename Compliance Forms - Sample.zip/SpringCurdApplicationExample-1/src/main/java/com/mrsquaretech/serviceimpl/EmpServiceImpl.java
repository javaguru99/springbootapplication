package com.mrsquaretech.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mrsquaretech.entity.Employee;
import com.mrsquaretech.repository.EmpRepository;
import com.mrsquaretech.service.EmpSerice;

@Service
public class EmpServiceImpl implements EmpSerice {

	@Autowired
	EmpRepository empRepository;

	public Employee saveEmp(Employee employee) {
		
		return empRepository.save(employee);
	}

}
