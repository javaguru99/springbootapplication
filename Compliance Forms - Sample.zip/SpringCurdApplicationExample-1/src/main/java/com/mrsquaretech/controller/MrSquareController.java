package com.mrsquaretech.controller;

public class MrSquareController {

}
