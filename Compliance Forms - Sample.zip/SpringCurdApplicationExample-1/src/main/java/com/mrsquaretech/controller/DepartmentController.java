package com.mrsquaretech.controller;

public class DepartmentController {

}
