package com.mrsquaretech.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.mrsquaretech.entity.Employee;
import com.mrsquaretech.service.EmpSerice;

public class EmpController {

	@Autowired
	EmpSerice empSerice;

	@PostMapping("/saveEmp")
	public Employee saveEmp(@RequestBody Employee employee) {

		return empSerice.saveEmp(employee);
	}
}
