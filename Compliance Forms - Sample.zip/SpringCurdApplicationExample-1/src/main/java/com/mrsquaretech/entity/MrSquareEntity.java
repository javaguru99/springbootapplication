package com.mrsquaretech.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class MrSquareEntity {
	@Id
	@GeneratedValue
	private Integer id;
	private String Name;
	private Long Mno;
	private String city;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public Long getMno() {
		return Mno;
	}
	public void setMno(Long mno) {
		Mno = mno;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}

}
