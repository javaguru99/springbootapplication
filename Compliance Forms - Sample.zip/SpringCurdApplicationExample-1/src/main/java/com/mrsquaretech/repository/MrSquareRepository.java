package com.mrsquaretech.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mrsquaretech.entity.MrSquareEntity;

public interface MrSquareRepository extends JpaRepository<MrSquareEntity, Integer> {

}
