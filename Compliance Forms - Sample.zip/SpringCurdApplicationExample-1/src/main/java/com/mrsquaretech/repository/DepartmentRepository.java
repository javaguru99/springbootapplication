package com.mrsquaretech.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mrsquaretech.entity.DepartmentEntity;

public interface DepartmentRepository extends JpaRepository<DepartmentEntity, Integer>{

}
