package com.mrsquaretech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCurdApplicationExample1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringCurdApplicationExample1Application.class, args);
	}

}
